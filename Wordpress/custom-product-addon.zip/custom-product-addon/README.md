# Custom Product Add-on Block

A lightweight WordPress plugin that adds a **Services** custom post type and a
`[cpa_recent_services]` shortcode. The shortcode shows the 3 most recently
updated services as cards, each with a **live price calculator** for optional
add-ons (vanilla JS, no jQuery, no libraries).

- Requires WordPress 6.3+ and PHP 7.4+
- No build step, no external dependencies

## Setup

1. Copy the `custom-product-addon` folder to `wp-content/plugins/` (or upload the zip via **Plugins > Add New > Upload**).
2. Activate **Custom Product Add-on Block**.
3. Go to **Services > Add New**. Fill in the title, excerpt, featured image, and in the **Service Details** box set **Base Price** and **Delivery Time (days)**.
4. Add `[cpa_recent_services]` to any page or post. In Elementor, use the **Shortcode** widget.
5. If `/services/...` links show a 404, go to **Settings > Permalinks** and click **Save Changes** once.

Optional attribute: `[cpa_recent_services title="Our Latest Work"]`.

## How it maps to the task

| Requirement | Where |
|---|---|
| (a) Services CPT + `base_price` and `delivery_time_days` | `includes/class-cpa-post-type.php`, `includes/class-cpa-meta-boxes.php` |
| (b) Block/shortcode with the 3 most recently updated services | `includes/class-cpa-shortcode.php` (`WP_Query`, `orderby => modified`) |
| (c) Vanilla JS calculator with add-ons and live total | `assets/js/calculator.js`, `templates/service-card.php` |
| (d) `WP_Query`/prepared queries, escaped output, `wp_enqueue_*` with dependencies | every file; assets in `includes/class-cpa-assets.php` |

The only add-on is **Priority Turnaround (+$50)**. More can be added without
editing the plugin, via the `cpa_addons` filter:

```php
add_filter( 'cpa_addons', function ( $addons ) {
	$addons[] = array( 'id' => 'rush-support', 'label' => 'Rush Support', 'price' => 20 );
	return $addons;
} );
```

## Rubric checklist

**Platform standards**
- Prefixed names everywhere (`CPA_*`, `cpa_*`, `cpa-block` text domain), class-per-file structure, ABSPATH guards.
- Right hooks: `init` (CPT, meta), `add_meta_boxes`, `save_post_service`, `wp_enqueue_scripts`, `manage_service_posts_*`, `the_content`.
- `register_post_meta()` with sanitize callbacks and `show_in_rest`.
- Activation and deactivation hooks flush rewrite rules.
- Translatable strings (`__()`, `_n()`) and a documented `cpa_addons` filter.

**Performance and code**
- Only `WP_Query`, no raw SQL. `no_found_rows` and `update_post_term_cache => false` skip needless queries.
- CSS and JS load only on pages that use them. Script is `defer` in the footer.
- Zero dependencies (the dependency arrays are intentionally empty and commented).
- JS: one delegated listener for the whole page, integer-cent math, the DOM is only touched when the total text changes.
- Modular files: assets class, helpers, template part, separate CSS and JS.

**State and edge cases**
- **Unavailable service** (no or zero base price): card shows "On request", add-ons and total are hidden, with a clear notice.
- **No services published**: friendly empty message instead of blank space.
- **JS or `Intl` failure**: server renders the correct base total, and the JS formatter falls back to a plain `$0.00` string.
- **Back/forward cache** restores checked toggles: totals are recalculated on `pageshow`.
- **Bad values**: invalid or negative numbers count as 0 in PHP and JS.
- **Responsive**: 1 column on phones, auto-fits to 2 or 3 columns on larger screens, fluid type and spacing, no fixed widths.
- **Sanitization**: nonce, autosave and capability checks on save; `esc_html`, `esc_attr`, `esc_url`, `wp_kses_post` on output.

**Accessibility**
- Semantic markup: `section`, `article`, `h2`/`h3`, `dl`, `fieldset`/`legend`, `footer`.
- Add-ons are native checkboxes with `role="switch"`: keyboard operable (Tab, Space) with the checked state exposed as `aria-checked`.
- Visible `:focus-visible` outline on the toggle.
- Total is an `<output aria-live="polite">`, so price changes are announced.
- `prefers-reduced-motion` and `forced-colors` are respected.

## Manual test checklist

- [ ] Services list shows Base Price and Delivery Time columns.
- [ ] Shortcode shows exactly 3 services; editing an older service moves it to the front.
- [ ] Toggling Priority Turnaround changes the total by exactly $50.00 and back.
- [ ] Keyboard only: Tab to the toggle, press Space, total updates and is announced.
- [ ] Service with price 0 shows "On request" and no calculator.
- [ ] Resize from 320px to 1400px: no horizontal scroll, layout reflows cleanly.
- [ ] View page source: assets are loaded via enqueue (no inline `<script>` tags from the plugin).

## Structure

```
custom-product-addon/
  custom-product-addon.php        bootstrap, constants, activation hooks
  includes/
    class-cpa-post-type.php       Services CPT
    class-cpa-meta-boxes.php      base_price, delivery_time_days
    class-cpa-admin-columns.php   Dashboard list columns
    class-cpa-single-view.php     details on a single service page
    class-cpa-assets.php          register / enqueue CSS + JS
    class-cpa-shortcode.php       [cpa_recent_services] + WP_Query
    helpers.php                   data access + formatting helpers
  templates/service-card.php      card markup (all output escaped)
  assets/js/calculator.js         vanilla JS calculator
  assets/css/calculator.css       responsive styles
```

## Git workflow

Work is committed in small, single-purpose commits using Conventional Commit
messages (`feat:`, `style:`, `docs:`, `chore:`). See `git log --oneline`.
